# Humanizer

Rewrite AI-sounding text so it reads like the writer without changing what it says. Built on Wikipedia's [Signs of AI writing](https://en.wikipedia.org/wiki/Signs_of_AI_writing).

This copy is prepared for **Codex** and **OpenCode**, which both read Agent Skills from a skill folder. The editing method is unchanged from upstream Humanizer 3.1.0. Only the packaging and install notes were adjusted.

**Before:**

> I'm thrilled to announce that shared drafts are finally here! 🚀 For months, our own team was drowning in files named final_v7.docx — and we knew there had to be a better way. Now two people can edit the same doc at once, with every change appearing live for both of them. It's not just a feature; it's a whole new way to collaborate. Let that sink in.

**After:**

> Shared drafts are out today. For months our own team passed around files named final_v7.docx, so we built a way for two people to edit the same doc at once, with each person's changes showing up live for the other. It's free on every plan.

Humanizer edits for human readers. Getting past AI detectors is not a goal, and detectors still flag most of its output.

## Install

The skill folder must be named exactly `humanizer` and contain `SKILL.md` at its top level.

User-level install, shared by Codex and OpenCode:

```text
%USERPROFILE%\.agents\skills\humanizer\
```

PowerShell:

```powershell
$dest = "$env:USERPROFILE\.agents\skills\humanizer"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Recurse -Force ".\humanizer\*" $dest
```

Restart the assistant or start a new session if the skill does not appear in the list.

Project-level install: place the same folder under `.agents/skills/humanizer/` inside the repository. Both hosts pick up repository skills there.

## Use

Ask in plain language:

```text
Humanize this text: [paste your text]
```

To rewrite a file, give the path:

```text
Humanize the prose in docs/launch-post.md
```

To match your voice, add a sample of your own writing. The sample overrides the pattern rules, including the dash rule.

## What it returns

- **Pasted text.** A draft rewrite, a short list of patterns that still remain, and the final version.
- **File mode.** Only the final prose is written to the file. Code, commands, paths, YAML metadata, data, and link targets stay unchanged.
- **Embedded mode.** When another task calls the skill for a commit message or document, only the final text is returned.

## How it works

A language model picks whatever is most likely to come next, so it defaults to wording that fits the widest range of readers. A person writes for one reader about one subject. Every pattern below is a version of that default.

The skill marks the tells strongest first, drafts a rewrite without treating the original structure as fixed, checks that no fact was added or dropped, then writes the final version. Missing detail is requested from the writer, never invented.

## The 26 patterns

| # | Pattern |
|---|---------|
| 1 | **Not X but Y** |
| 2 | **One-line closers and dramatic fragments** |
| 3 | **Sayings that sound deep** |
| 4 | **Staged run-up before the point** |
| 5 | **Arguing with no one** |
| 6 | **Forced triads** |
| 7 | **Repeated sentence openings** |
| 8 | **Dashes as the universal connector** |
| 9 | **Stacked qualifiers** |
| 10 | **Hyphenated pairs everywhere** |
| 11 | **Passive voice and missing subjects** |
| 12 | **Overused AI words** |
| 13 | **Inflated significance** |
| 14 | **Vague connection or association** |
| 15 | **Shallow -ing riders** |
| 16 | **Sales language** |
| 17 | **Borrowed authority** |
| 18 | **Avoiding is, are, and has** |
| 19 | **Bold as decoration** |
| 20 | **Decorative headings** |
| 21 | **Curly quotation marks** |
| 22 | **Chatbot residue** |
| 23 | **Knowledge-limit disclaimers and guesses** |
| 24 | **A heading repeated in the first sentence** |
| 25 | **Writing about the document instead of its subject** |
| 26 | **Re-explaining what the reader knows** |

The full instructions, examples, and false-positive guards are in `SKILL.md`.

## Check the package

`scripts/validate-skill.py` needs Python 3.10 or newer and no other dependencies:

```powershell
python scripts\validate-skill.py .
```

It checks the frontmatter, the folder name, the description length, pattern numbering, cross-references, README pattern names, and the word budget.

## What was changed for Codex and OpenCode

- The folder keeps a single `SKILL.md` at the top level, which both hosts load.
- Install and usage notes describe the shared `.agents/skills` path.
- Claude and Cursor plugin manifests and the repository maintenance guide were removed: they belong to upstream packaging and are not read by Codex or OpenCode.
- `scripts/validate-package.py` was replaced by `scripts/validate-skill.py`, which checks the skill folder instead of plugin manifests.

The pattern text, numbering, examples, and the editor instruction were not changed. Upstream: [blader/humanizer](https://github.com/blader/humanizer).

## Limitations

- Triggering is controlled by the host, not by this package. The `description` field is the only signal both hosts use.
- The file was tested as a skill folder structure, not by running real editing tasks in both hosts.
- Detector evasion is out of scope.

## License

MIT. See `LICENSE`.
