#!/usr/bin/env python3
"""Check a Humanizer skill folder for Codex and OpenCode. No external dependencies."""

from __future__ import annotations

import re
import sys
from pathlib import Path


MAX_DESCRIPTION = 1024
MAX_WORDS = 5500


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError as error:
        fail(f"cannot read {path}: {error}")


def main(argv: list[str]) -> int:
    root = Path(argv[1]).resolve() if len(argv) > 1 else Path(__file__).resolve().parent.parent
    if not root.is_dir():
        fail(f"{root} is not a folder")

    skill_files = [path for path in root.rglob("SKILL.md")]
    if len(skill_files) != 1:
        fail(f"expected exactly one SKILL.md, found {len(skill_files)}")
    skill_path = skill_files[0]
    if skill_path.parent != root:
        fail("SKILL.md must sit at the top level of the skill folder")
    if skill_path.is_symlink():
        fail("SKILL.md must be a regular file, not a symlink")

    skill = read_text(skill_path)
    readme_path = root / "README.md"
    readme = read_text(readme_path) if readme_path.exists() else ""

    metadata_match = re.match(r"\A---\n(.*?)\n---\n", skill, re.DOTALL)
    if metadata_match is None:
        fail("SKILL.md must begin with YAML frontmatter")
    metadata = metadata_match.group(1)

    name_match = re.search(r"(?m)^name:\s*(\S+)\s*$", metadata)
    if name_match is None:
        fail("add name to the frontmatter")
    name = name_match.group(1).strip("\"'")
    if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name):
        fail(f"name must be lowercase kebab-case: {name!r}")
    if name != root.name:
        fail(f"folder name {root.name!r} must match name {name!r}")

    description = ""
    block = re.search(r"(?m)^description:\s*\|\n((?:[ \t]+.*\n)+)", metadata)
    if block is not None:
        description = " ".join(block.group(1).split())
    else:
        single = re.search(r"""(?m)^description:\s*(["']?)(.+?)\1\s*$""", metadata)
        if single is not None:
            description = " ".join(single.group(2).replace("\\n", " ").split())
    if not description:
        fail("add description to the frontmatter")
    if len(description) > MAX_DESCRIPTION:
        fail(f"description has {len(description)} characters; keep it at or below {MAX_DESCRIPTION}")

    version_match = re.search(r"(?m)^\s+version:\s*[\"']?([0-9]+\.[0-9]+\.[0-9]+)[\"']?\s*$", metadata)
    if version_match is None:
        print("WARNING: metadata.version is missing; package versions cannot be matched")

    patterns = dict(
        (int(number), title.strip())
        for number, title in re.findall(r"(?m)^### ([0-9]+)\. (.+)$", skill)
    )
    numbers = list(patterns)
    if not numbers:
        fail("no numbered patterns found; expected headings such as '### 1. ...'")
    if numbers != list(range(1, len(numbers) + 1)):
        fail(f"number patterns from 1 upward without gaps: {numbers}")

    missing_refs = sorted(
        {int(number) for number in re.findall(r"§([0-9]+)", skill)}
        - set(range(1, len(numbers) + 1))
    )
    if missing_refs:
        fail(f"section references point at missing patterns: {missing_refs}")

    if readme:
        listed = dict(
            (int(number), title.strip())
            for number, title in re.findall(r"(?m)^\| ([0-9]+) \| \*\*(.+?)\*\*", readme)
        )
        if sorted(listed) != numbers:
            fail(f"README must list patterns 1 through {len(numbers)} once each: {sorted(listed)}")
        renamed = [
            f"{number}: README has {listed[number]!r}, SKILL.md has {patterns[number]!r}"
            for number in patterns
            if listed[number] != patterns[number]
        ]
        if renamed:
            fail("pattern titles differ: " + "; ".join(renamed))
        if f"## The {len(numbers)} patterns" not in readme:
            fail(f"README must contain the heading '## The {len(numbers)} patterns'")

    words = len(skill.split())
    if words > MAX_WORDS:
        fail(f"SKILL.md has {words} words; keep it at or below {MAX_WORDS}")

    print(f"OK: {name} v{version_match.group(1) if version_match else 'unknown'}, {len(numbers)} patterns, {words} words")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
