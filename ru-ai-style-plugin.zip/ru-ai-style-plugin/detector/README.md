# Детектор aiw-ru

Автономная копия Python-детектора из проекта `avoid-ai-writing-russian` (MIT, Ilya Lubenets).
Нужен навыку `antiplagiat` для замера по фрагментам, `validate` и калибровки по отчётам.
`ru-ai-style` работает и без него, но тогда сохранность правки проверяется вручную, а находки не имеют позиций и оценки.

## Установка (рекомендуется)

```bash
uv tool install "<путь к detector>"
aiw-ru scan <файл> --context vak
aiw-ru validate <исходный> <исправленный>
```

После установки команда `aiw-ru` доступна из любой папки, префикс `uv run --project ...` не нужен.

Если `uv` нет, поставь через pip. Нужны Python 3.12+ и сеть:

```bash
python -m pip install "<путь к detector>"
python -m aiw_ru --version   # если aiw-ru не попал в PATH
```

Так ставится и детектор в веб-песочнице Claude, где `uv` обычно отсутствует: папка `detector` лежит в плагине рядом с `skills/`, из папки навыка это `${CLAUDE_SKILL_DIR}/../../detector`.

На Windows перед запуском включи UTF-8, иначе таблица падает на кодировке консоли или печатает вопросительные знаки:

```powershell
$env:PYTHONIOENCODING = "utf-8"
[Console]::OutputEncoding = [Text.Encoding]::UTF8
```

## Запуск без установки

```bash
uv run --project <путь к detector> aiw-ru scan <файл> --context vak
uv run --project <путь к detector> aiw-ru validate <исходный> <исправленный>
uv run --project <путь к detector> aiw-ru antiplagiat <файл> --explain
```

Первый запуск создаст окружение и поставит зависимости (`pydantic`, `regex`, `rich`).

## Модели вероятности (необязательно)

Правила, `scan`, `validate`, `antiplagiat` и `calibrate` работают без моделей.
Модели ставятся отдельно и весят сотни мегабайт:

```bash
uv tool install "<путь к detector>[ml]"
aiw-ru models install
```

Файлы весов скачиваются с Hugging Face при установке модели.

## Ограничения и отличия копии

Убрана сборка `skills/` в пакет: здесь только код детектора, а сами навыки лежат рядом
в папке `skills/` плагина. Команда `aiw-ru skill` в этой копии может не найти скиллы;
для работы навыков она не нужна.

Граница зелёной зоны в `antiplagiat` понижена до 10 % (`GREEN_BELOW` в `antiplagiat.py`):
цель правки — ниже 10 %, а не ниже 40 %, как в оригинале. Порог красной зоны и модель по
умолчанию не менялись, поэтому жёлтая зона шире: от 10 % до порога.
