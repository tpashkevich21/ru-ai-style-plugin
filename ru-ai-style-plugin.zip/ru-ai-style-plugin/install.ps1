﻿# Установка плагина ru-ai-style на Windows.
# Копирует оба навыка в общий каталог навыков и ставит детектор aiw-ru.
#
#   powershell -ExecutionPolicy Bypass -File .\install.ps1
#
# Параметры:
#   -SkillsDir <путь>   куда копировать навыки (по умолчанию ~\.agents\skills)
#   -SkipDetector       только навыки, без установки aiw-ru

[CmdletBinding()]
param(
    [string]$SkillsDir = (Join-Path $HOME '.agents\skills'),
    [switch]$SkipDetector
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$names = @('ru-ai-style', 'antiplagiat')

Write-Host "Плагин: $root"
Write-Host "Навыки: $SkillsDir"
Write-Host ''

foreach ($name in $names) {
    $src = Join-Path $root "skills\$name"
    if (-not (Test-Path $src)) {
        throw "Не найдена папка навыка: $src. Запускайте скрипт из корня плагина."
    }
    $dst = Join-Path $SkillsDir $name
    if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null
    Copy-Item $src $dst -Recurse -Force
    Write-Host "  навык $name -> $dst"
}

if ($SkipDetector) {
    Write-Host ''
    Write-Host 'Детектор не ставился (-SkipDetector).'
    exit 0
}

$detector = Join-Path $root 'detector'
if (-not (Test-Path $detector)) {
    throw "Не найдена папка detector: $detector"
}

Write-Host ''
$uv = Get-Command uv -ErrorAction SilentlyContinue
if ($uv) {
    Write-Host 'Ставлю детектор через uv...'
    & uv tool install $detector --force
    if ($LASTEXITCODE -ne 0) { throw "uv tool install завершился с кодом $LASTEXITCODE" }
    & uv tool update-shell | Out-Null
} else {
    Write-Host 'uv не найден, ставлю детектор через pip (нужен Python 3.12+)...'
    & python -m pip install --user --upgrade $detector
    if ($LASTEXITCODE -ne 0) { throw "pip install завершился с кодом $LASTEXITCODE" }
}

# Без UTF-8 таблицы детектора ломаются на кодировке консоли Windows.
[Environment]::SetEnvironmentVariable('PYTHONIOENCODING', 'utf-8', 'User')
$env:PYTHONIOENCODING = 'utf-8'

Write-Host ''
Write-Host 'Проверка:'
$found = $false
$aiw = Get-Command aiw-ru -ErrorAction SilentlyContinue
if ($aiw) {
    & aiw-ru --version
    $found = $true
}
if (-not $found) {
    $shim = Join-Path $HOME '.local\bin\aiw-ru.exe'
    if (Test-Path $shim) {
        & $shim --version
        Write-Host "  PATH обновится в новом терминале; до этого зовите $shim"
        $found = $true
    }
}
if (-not $found) {
    $out = & python -m aiw_ru --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $out
        Write-Host '  aiw-ru не попал в PATH: зовите детектор как python -m aiw_ru'
        $found = $true
    }
}
if (-not $found) {
    throw 'Детектор установлен, но не запускается. Проверьте Python 3.12+ и PATH.'
}

Write-Host ''
Write-Host 'Готово. Перезапустите терминал и сессию агента, чтобы подхватились PATH и PYTHONIOENCODING.'
