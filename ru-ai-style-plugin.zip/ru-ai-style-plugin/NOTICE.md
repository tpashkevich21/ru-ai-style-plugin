# Происхождение и лицензии

Плагин `ru-ai-style` распространяется по лицензии MIT. Он содержит два навыка.

## skills/ru-ai-style

Объединённый производный навык. Собран из:

- `slopotron` — MIT, Copyright (c) 2026 Rodion Scryabin (beaverbeard);
- `avoid-ai-writing-russian` — MIT, Copyright (c) 2026 Conor Bronsdon; Copyright (c) 2026 Ilya Lubenets.

Полная атрибуция, список адаптированных файлов и внешние источники — в `skills/ru-ai-style/NOTICE`.

## skills/antiplagiat

Под-навык проекта `avoid-ai-writing-russian`.

- Лицензия: MIT. Copyright (c) 2026 Ilya Lubenets.
- Адаптация для пакета: `parent_skill` и ссылки на основной навык переведены на `ru-ai-style`; команды `uv run --project ../.. aiw-ru` заменены на прямой вызов `aiw-ru`; пути `../avoid-ai-writing-russian/references/*` — на `../ru-ai-style/references/full/*`.

## Детектор и внешние зависимости

- **`detector/`** — исходники `aiw-ru` из проекта `avoid-ai-writing-russian` (MIT, Copyright (c) 2026 Ilya Lubenets). Изменения для автономной копии: убраны сборка `skills/` в пакет и поля `readme`/`license-files` в `pyproject.toml`; граница зелёной зоны в `antiplagiat` понижена с 40 % (порог минус 0,1) до 10 % (`GREEN_BELOW`), порог красной зоны не менялся. Остальной код и зависимости не менялись.
- **Веса моделей** — не входят, скачиваются отдельно при `models install`.
- «Антиплагиат» — товарный знак АО «Антиплагиат». «Думейт» — сервис domate.ru. Навык с ними не связан и не воспроизводит их классификаторы.
