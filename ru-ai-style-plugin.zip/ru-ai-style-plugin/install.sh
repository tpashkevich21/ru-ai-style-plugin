#!/usr/bin/env bash
# Установка плагина ru-ai-style на macOS и Linux.
# Копирует оба навыка в общий каталог навыков и ставит детектор aiw-ru.
#
#   bash install.sh
#
# Переменные окружения:
#   SKILLS_DIR=<путь>   куда копировать навыки (по умолчанию ~/.agents/skills)
#   SKIP_DETECTOR=1     только навыки, без установки aiw-ru
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
skills="${SKILLS_DIR:-$HOME/.agents/skills}"

echo "Плагин: $root"
echo "Навыки: $skills"
echo

for name in ru-ai-style antiplagiat; do
  src="$root/skills/$name"
  if [ ! -d "$src" ]; then
    echo "Не найдена папка навыка: $src" >&2
    exit 1
  fi
  mkdir -p "$skills"
  rm -rf "$skills/$name"
  cp -R "$src" "$skills/$name"
  echo "  навык $name -> $skills/$name"
done

if [ "${SKIP_DETECTOR:-0}" = "1" ]; then
  echo
  echo "Детектор не ставился (SKIP_DETECTOR=1)."
  exit 0
fi

detector="$root/detector"
if [ ! -d "$detector" ]; then
  echo "Не найдена папка detector: $detector" >&2
  exit 1
fi

echo
if command -v uv >/dev/null 2>&1; then
  echo "Ставлю детектор через uv..."
  uv tool install "$detector" --force
  uv tool update-shell || true
else
  echo "uv не найден, ставлю детектор через pip (нужен Python 3.12+)..."
  python3 -m pip install --user --upgrade "$detector"
fi

echo
echo "Проверка:"
found=0
if command -v aiw-ru >/dev/null 2>&1; then
  aiw-ru --version
  found=1
fi
if [ "$found" = "0" ] && [ -x "$HOME/.local/bin/aiw-ru" ]; then
  "$HOME/.local/bin/aiw-ru" --version
  echo "  PATH обновится в новом терминале; до этого зовите $HOME/.local/bin/aiw-ru"
  found=1
fi
if [ "$found" = "0" ]; then
  if python3 -m aiw_ru --version 2>/dev/null; then
    echo "  aiw-ru не попал в PATH: зовите детектор как python3 -m aiw_ru"
    found=1
  fi
fi
if [ "$found" = "0" ]; then
  echo "Детектор установлен, но не запускается. Проверьте Python 3.12+ и PATH." >&2
  exit 1
fi

echo
echo "Готово. Перезапустите терминал и сессию агента, чтобы подхватились PATH."
